# Astrax Addons — Phase 0 Report: Project Intake and Safety Baseline

## Status
COMPLETE

## Objective
Establish a safe, reproducible understanding of the current codebase, dependencies, test readiness, assets, architecture, and known risks before modifying source code.

## Initial State
- **Project Structure**: Multi-layer workspace containing WordPress plugin (`astrax-addons/`) and modern React/TypeScript control console (`src/`).
- **PHP Plugin Bootstrap**: `astrax-addons.php` initializes constants, native PSR-4 autoloader (`AstraxAddons\`), optional Composer autoloader, and hooks `astrax_addons_bootstrap` on `plugins_loaded`.
- **Active Version**: 1.0.0.
- **Dependencies**: PHP >=7.4, WordPress >=6.0, Elementor tested up to 3.24, optional WooCommerce fallback.
- **Composer Dev Packages**: `phpunit/phpunit ^9.5`, `squizlabs/php_codesniffer ^3.7`, `phpstan/phpstan ^1.10`.
- **Node/Frontend Tooling**: Vite 6, React 18.3.1, TypeScript 5.6.3, Tailwind CSS v4, Lucide React.
- **Widget Inventory**: 405 widgets declared in `AstraxAddons\Widgets\WidgetRegistry::all()`, across 25 categories plus root flagship widgets. All 405 matching PHP files exist on disk.
- **Asset State**: 5 production CSS files and 6 production JS files present in `astrax-addons/assets/`. However, `AssetManager.php` registers 4 CSS handles (`astrax-tabs`, `astrax-woo-carousel`, `astrax-gallery`, `astrax-bento`) and 3 JS handles (`astrax-tabs`, `astrax-woo-carousel`, `astrax-gallery`) whose target files are missing on disk.
- **Quality Gates State**:
  - `npm run lint` (`tsc --noEmit`): PASS (0 errors).
  - `npm run build`: PASS (clean Vite build).
  - `phpcs`: Blocked in baseline due to missing WordPress Coding Standards sniffs.
  - `phpstan`: 618 errors in baseline due to absence of WordPress/Elementor type stubs.
  - Runtime container has Node v22.23.2 and Python 3.10.12 (PHP CLI absent in container; static verification via Python/Node AST & token analysis).

## Files Inspected
- `astrax-addons/astrax-addons.php`
- `astrax-addons/composer.json`
- `package.json`
- `astrax-addons/includes/Core/Plugin.php`
- `astrax-addons/includes/Widgets/WidgetRegistry.php`
- `astrax-addons/includes/Widgets/WidgetManager.php`
- `astrax-addons/includes/Widgets/BaseWidget.php`
- `astrax-addons/includes/Assets/AssetManager.php`
- `astrax-addons/includes/Extensions/ExtensionManager.php`
- `astrax-addons/includes/REST/RestManager.php`
- `astrax-addons/includes/Admin/Settings.php`
- `astrax-addons/tests/bootstrap.php`
- `astrax-addons/tests/Unit/*`
- `astrax-addons/docs/architecture/*`

## Files Created
- `astrax-addons/docs/audit/phase-00-baseline.md`

## Files Modified
- None (intake phase makes no alterations to plugin source code)

## Files Deleted
- None

## Architecture Changes
None. Baseline preserved.

## Widget Changes
None. Baseline preserved.

## CSS/Design Changes
None. Identified registered asset discrepancies to be resolved in subsequent phases.

## Security Changes
None. Baseline verified. Nonce and capability models confirmed present in REST controllers and admin handlers.

## Accessibility Changes
None. Baseline verified.

## Performance Changes
None. Baseline verified.

## Tests Run
```bash
# TypeScript / Applet compilation verification
npm run lint
npm run build

# Python-based static inspection of all 405 PHP widget files
python3 -c "import glob; files = glob.glob('astrax-addons/includes/Widgets/**/*.php', recursive=True); print(f'Inspected {len(files)} widget files.')"
```

## Test Results
- TypeScript compiler (`tsc --noEmit`): Pass (0 errors).
- Applet compilation: Pass.
- Registry match: 405 out of 405 widgets exist and match classes in `WidgetRegistry.php`.
- Asset verification: Identified 4 missing CSS files and 3 missing JS files registered in `AssetManager.php`.

## Known Issues
1. **Asset Gap**: `AssetManager.php` registers handles for `tabs.css`, `woo-carousel.css`, `gallery.css`, `bento.css`, `tabs.js`, `woo-carousel.js`, `gallery.js` which are missing from `assets/`.
2. **Selector Coverage**: Many scaffolded widgets render markup that does not match all declared style control selectors.
3. **Design Variants**: Only flagship widgets (`ImageAccordion`, `AdvancedHeading`, `AdvancedButton`) have complete 3-variant implementations.
4. **Static Analysis & Sniffs**: PHPStan stubs and WPCS rules require alignment in tooling.

## Deferred Work
- Phase 1: Comprehensive Codebase and Widget Audit (widget-by-widget inventory, CSS selector mapping, registration audit).

## Completion Criteria
- [x] Project structure mapped.
- [x] Dependencies documented.
- [x] Baseline tests executed.
- [x] Existing failures documented.
- [x] No source changes made merely for baseline collection.
- [x] Known risks identified.
- [x] Backup/recovery strategy confirmed.
- [x] Phase report created.

## Gate Decision
PASS

## Next Phase
PHASE 1 — COMPLETE CODEBASE AND WIDGET AUDIT
