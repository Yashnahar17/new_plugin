# Threat Model

## Assets
- WordPress Database (Posts, Settings, Users).
- Elementor Templates/Settings.
- Admin Dashboard.

## Threat Agents
- Unauthenticated Users (Public visitors).
- Authenticated Users (Subscribers, Authors, Editors).
- Malicious Third-party plugins.

## Identified Threats & Mitigations

### 1. Cross-Site Scripting (XSS)
- **Threat**: Attackers inject malicious scripts via widget inputs or REST API.
- **Mitigation**: Late contextual escaping (`esc_html`, `esc_attr`, `wp_kses_post`) on all outputs. Sane validation on inputs.

### 2. Cross-Site Request Forgery (CSRF)
- **Threat**: Attacker forces an authenticated admin to perform actions (e.g., changing settings).
- **Mitigation**: Implement `wp_verify_nonce()` on all state-changing endpoints and form submissions.

### 3. Privilege Escalation / Broken Access Control
- **Threat**: Subscriber accesses admin API or modifies Elementor layouts.
- **Mitigation**: Server-side capability checks (`current_user_can('manage_options')` or `edit_posts`) on REST endpoints and AJAX handlers.

### 4. SQL Injection
- **Threat**: Malicious input passed into database queries.
- **Mitigation**: Exclusively use `$wpdb->prepare()` for dynamic queries. Cast integers and whitelist identifiers.

### 5. Remote Code Execution (RCE) / Path Traversal
- **Threat**: Exploiting file inclusion or execution vectors.
- **Mitigation**: Ban `eval()`, dynamic untrusted includes. Enforce path traversal checks (`realpath`, `basename`).

### 6. SSRF / Malicious Uploads
- **Threat**: Plugin makes unsafe outbound HTTP requests or allows unsafe file uploads.
- **Mitigation**: Use `wp_safe_remote_get/post`. Verify MIME types, extensions, and file contents upon upload.
