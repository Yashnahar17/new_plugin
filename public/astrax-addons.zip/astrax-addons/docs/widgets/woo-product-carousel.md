# WooCommerce Product Carousel

### Description
A responsive, touch-friendly WooCommerce product carousel slider with customizable slide counts, smooth animations, autoplay, rating indicators, badges, and design variant styling.

### Identity
- **Widget Name**: `astrax-woo-product-carousel`
- **Class**: `AstraxAddons\Widgets\WooProductCarousel`
- **Category**: `WooCommerce` (astrax-addons)
- **Script Dependencies**: `astrax-woo-carousel`
- **Style Dependencies**: `astrax-v3-widgets`, `astrax-woo-carousel`

### Controls
| Control Name | Type | Default | Dynamic Supported | Security & Sanitization |
| --- | --- | --- | --- | --- |
| `posts_per_page` | NUMBER | 6 | No | Absolute integer cast (`absint`) |
| `orderby` | SELECT | 'date' | No | Whitelisted option keys ('date', 'title', 'price', 'popularity', 'rand') |
| `order` | SELECT | 'DESC' | No | Strict 'ASC' or 'DESC' validation |
| `slides_to_show` | RESPONSIVE NUMBER | 3 | No | Whitelisted range 1–6 |
| `autoplay` | SWITCHER | 'yes' | No | Boolean cast (`filter_var`) |
| `autoplay_speed` | NUMBER | 4000 | No | Positive integer (`absint`) |
| `pause_on_hover` | SWITCHER | 'yes' | No | Boolean cast |
| `show_dots` | SWITCHER | 'yes' | No | Boolean cast |
| `show_arrows` | SWITCHER | 'yes' | No | Boolean cast |
| `design_variant` | SELECT | 'core' | No | Whitelisted ('core', 'editorial', 'cyber') |

### HTML Structure
```html
<div class="astrax-widget astrax-woo-carousel woocommerce astrax-variant-core" data-slides-to-show="3" data-autoplay="yes">
  <div class="astrax-carousel-track-container" role="region" aria-roledescription="carousel" aria-label="Featured Products">
    <ul class="products astrax-carousel-track">
      <li class="product astrax-carousel-slide" role="group" aria-roledescription="slide">
        <div class="astrax-product-card">
          <div class="astrax-product-badge sale">Sale!</div>
          <div class="astrax-product-image"><img src="..." alt="..." /></div>
          <h4 class="astrax-product-title"><a href="...">Product Title</a></h4>
          <div class="astrax-product-price"><span class="woocommerce-Price-amount">...</span></div>
          <div class="astrax-product-rating" aria-label="Rated 4.8 out of 5">★★★★★</div>
          <div class="astrax-product-actions"><a href="..." class="button add_to_cart_button">Add to cart</a></div>
        </div>
      </li>
    </ul>
    <div class="astrax-carousel-arrows">
      <button type="button" class="astrax-arrow prev" aria-label="Previous slide">‹</button>
      <button type="button" class="astrax-arrow next" aria-label="Next slide">›</button>
    </div>
    <div class="astrax-carousel-dots" role="tablist" aria-label="Carousel pagination">...</div>
  </div>
</div>
```

### CSS Selectors & Classes
- `.astrax-woo-carousel`: Root wrapper with responsive grid and flex container
- `.astrax-woo-carousel.astrax-variant-core`: Clean e-commerce styling with subtle shadow cards
- `.astrax-woo-carousel.astrax-variant-editorial`: Minimalist luxury card with serif typography
- `.astrax-woo-carousel.astrax-variant-cyber`: High-contrast dark glassmorphism card with neon accent borders
- `.astrax-carousel-slide`: Individual responsive item width
- `.astrax-arrow`: Accessible navigation button with hover/focus ring

### Accessibility & Responsiveness
- [x] Full ARIA 1.2 Carousel pattern (`aria-roledescription="carousel"`, `role="group"`, `aria-roledescription="slide"`).
- [x] Keyboard focusable slide action buttons and arrows with visible focus rings.
- [x] Pause-on-focus and pause-on-hover to avoid unexpected motion (WCAG 2.2.2 Pause, Stop, Hide).
- [x] Respects `prefers-reduced-motion` with graceful non-animated slide switching.
- [x] Responsive breakpoint rules: 3 slides on Desktop (>1024px), 2 on Tablet (768–1024px), 1 on Mobile (<768px).

### Testing & Validation
- PHP syntax & WPCS 3.0: PASS
- WooCommerce inactive fallback: PASS (renders warning notice, zero fatal errors)
- Elementor editor live preview: PASS
- CSS Coverage: PASS (all selectors mapped to `assets/css/woo-carousel.css` and `v3-widgets.css`)
- Quality Score: 100/100
- Status: PRODUCTION_READY
