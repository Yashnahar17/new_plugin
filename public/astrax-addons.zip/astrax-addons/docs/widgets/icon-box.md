# Icon Box

### Description
Displays an icon accompanied by a heading and descriptive text.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| icon | Icons | 'fas fa-star' | No | Native Elementor Icons_Manager |
| title_text | text | 'This is the heading' | Yes | Contextual escaping (`esc_html`) |
| description_text | textarea | 'Lorem ipsum...' | Yes | Strict XSS sanitization (`RenderHelper::esc_rich_text()`) |
| title_size | select | 'h3' | No | Allowed via internal `render_html_tag` allowlist |

### HTML Structure
```html
<div class="astrax-icon-box-wrapper">
  <div class="astrax-icon-box-icon">
    <!-- SVG or Icon element -->
  </div>
  <div class="astrax-icon-box-content">
    <h3 class="astrax-icon-box-title">Title</h3>
    <p class="astrax-icon-box-description">Description text...</p>
  </div>
</div>
```

### Accessibility
- [x] Icons automatically receive `aria-hidden="true"` to prevent redundant screen reader announcements (content provides the context).
- [x] Semantic HTML headings used for the title.
