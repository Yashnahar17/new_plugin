# Filterable Gallery

### Description
A responsive image gallery widget featuring categories, filter buttons, lightbox preview triggers, and fluid grid layouts.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| layout | select | 'grid' | No | Internal logic routing |
| columns | responsive select | 3 | No | Whitelisted column values |
| show_filters | switcher | 'yes' | No | Boolean check |
| gallery_items | REPEATER | (sample items) | Yes | Repeater scope sanitization |
| - image | Media | Placeholder | Yes | Native Elementor attachment handler |
| - title | text | 'Photo Title' | Yes | Contextual escaping (`esc_html`) |
| - category | text | 'Nature' | Yes | `sanitize_text_field()` |
| design_variant | select | 'core' | No | `sanitize_key()` validation |

### HTML Structure
```html
<div class="astrax-widget astrax-gallery astrax-variant-core">
  <div class="astrax-gallery-filters" role="toolbar" aria-label="Gallery filters">
    <button class="astrax-filter-btn is-active" data-filter="*" aria-pressed="true">All</button>
  </div>
  <div class="astrax-gallery-grid">
    <div class="astrax-gallery-item" data-category="nature">
      <img src="..." alt="..." loading="lazy">
      <div class="astrax-gallery-overlay">...</div>
    </div>
  </div>
</div>
```

### Accessibility
- [x] Meaningful `alt` text forwarded from WordPress media library.
- [x] Filter toolbar navigable with keyboard tabs.
- [x] Active filter button communicates state with `aria-pressed="true"`.
- [x] Touch-friendly 44px min target heights on mobile devices.
