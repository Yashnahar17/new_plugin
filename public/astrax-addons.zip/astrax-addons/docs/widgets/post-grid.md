# Post Grid

### Description
A responsive multi-column blog post grid widget featuring query controls, pagination, categories, design variants (Core, Editorial, Cyber), and accessible post cards.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| posts_per_page | number | 6 | No | Absolute integer cast (`absint`) |
| category | select2 | '' | No | Sanitized text / term ID check |
| orderby | select | 'date' | No | Whitelisted parameter array |
| order | select | 'DESC' | No | Whitelisted parameter ('ASC', 'DESC') |
| design_variant | select | 'core' | No | `sanitize_key()` validation |
| show_thumbnail | switcher | 'yes' | No | Boolean check |
| show_excerpt | switcher | 'yes' | No | Boolean check |

### HTML Structure
```html
<div class="astrax-widget astrax-post-grid astrax-variant-core">
  <article class="astrax-post-grid-item">
    <div class="astrax-post-grid-thumbnail">
      <a href="..." aria-hidden="true" tabindex="-1"><img src="..." alt="..."></a>
    </div>
    <div class="astrax-post-grid-content">
      <h3 class="astrax-post-grid-title"><a href="...">Post Title</a></h3>
      <div class="astrax-post-grid-excerpt">Summary text...</div>
    </div>
  </article>
</div>
```

### Accessibility
- [x] Semantic `<article>` wrapping for individual post entries.
- [x] Heading hierarchy preserved (`<h3>` or configurable heading tag).
- [x] Keyboard focusable links with distinct focus rings.
- [x] Image link marked `aria-hidden="true"` with `tabindex="-1"` to prevent redundant screen reader announcements.
- [x] Reduced motion respected in hover states.
