# Advanced Heading

### Description
A highly customizable heading widget providing robust dynamic content support and strict escaping logic.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| heading_text | textarea | 'Add Your Heading Text Here' | Yes | Strict XSS sanitization via `RenderHelper::esc_rich_text()` |
| heading_tag | select | 'h2' | No | Allowed via internal `render_html_tag` allowlist |
| heading_link | URL | (empty) | Yes | URL protocols sanitized natively by Elementor link wrappers |

### HTML Structure
```html
<h2 class="astrax-heading-title">
  <a href="https://example.com">Heading Text</a>
</h2>
```
(If link is empty, the `<a>` tag is omitted).

### Accessibility
- [x] Semantic HTML tag selection (H1-H6, p, div, span).
- [x] Link focus states inherently supported by browsers.
- [ ] Reduced motion support (Not applicable - no inherent animation).
