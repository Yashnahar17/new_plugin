# Bento Grid

### Description
A modern asymmetric CSS grid widget providing flexible multi-column and multi-row layout spans, design variants, responsive stacking, and rich content cards.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| items | REPEATER | (2 defaults) | Yes | Repeater scope sanitization |
| - item_title | text | 'Bento Item' | Yes | Contextual escaping (`esc_html`) |
| - item_content | textarea | 'Item content' | Yes | Strict XSS sanitization (`RenderHelper::esc_rich_text`) |
| - col_span | responsive select | '1' | No | Validated grid span string |
| - row_span | responsive select | '1' | No | Validated grid span string |
| design_variant | select | 'core' | No | `sanitize_key()` validation |
| grid_gap | responsive slider | 20px | No | Elementor unit slider |
| item_bg_color | color | '' | No | Hex/rgba color sanitizer |
| item_title_color | color | '' | No | Hex/rgba color sanitizer |

### HTML Structure
```html
<div class="astrax-widget astrax-bento-grid astrax-variant-core">
  <div class="astrax-bento-item elementor-repeater-item-12345">
    <h3 class="astrax-bento-title">Title</h3>
    <div class="astrax-bento-content">Content...</div>
  </div>
</div>
```

### Accessibility
- [x] Heading hierarchy correctly starts with `<h3>`.
- [x] Rich content safely sanitizes embedded HTML.
- [x] Responsive CSS ensures no horizontal overflow on mobile viewports (< 768px).
