# Image Accordion

### Description
An advanced layout widget presenting a series of images in a flex-based accordion. Supports horizontal/vertical layouts, hover/click triggers, and full keyboard navigation.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| direction | select | 'horizontal' | No | Internal logic routing only |
| trigger | select | 'hover' | No | Data attribute mapping (`esc_attr`) |
| active_index | number | 1 | No | Parsed as absolute integer (`absint`) |
| items | REPEATER | (3 defaults) | Yes | Repeater scope escaping |
| - image | Media | Placeholder | Yes | Native Elementor `Group_Control_Image_Size::get_attachment_image_src()` |
| - title | text | 'Item X' | Yes | Contextual escaping (`esc_html`) |
| - description | textarea | '' | Yes | Strict XSS sanitization (`RenderHelper::esc_rich_text()`) |
| - link | URL | (empty) | Yes | URL protocols sanitized natively by Elementor link wrappers |

### HTML Structure
```html
<div class="astrax-image-accordion astrax-dir-horizontal" data-trigger="hover" role="tablist">
  <div class="astrax-ia-item is-active" role="tab" aria-selected="true" tabindex="0">
    <div class="astrax-ia-bg" style="background-image: ..."></div>
    <div class="astrax-ia-overlay"></div>
    <div class="astrax-ia-content" role="tabpanel">
       <h3 class="astrax-ia-title">Title</h3>
       <div class="astrax-ia-desc">...</div>
       <a href="#" class="astrax-ia-button" tabindex="0">Read More</a>
    </div>
  </div>
</div>
```

### Accessibility
- [x] Full `tablist`, `tab`, and `tabpanel` WAI-ARIA implementation.
- [x] Dynamic `aria-selected` and `tabindex` switching between active and inactive tabs.
- [x] Keyboard navigation supported natively via `image-accordion.js` (Arrow keys for traversing, Enter/Space for activating 'click' triggers).
- [x] Reduced motion explicitly respected in `image-accordion.css` via `@media (prefers-reduced-motion: reduce)`.
