# Interactive Tabs

### Description
An accessible tabbed content navigation widget with horizontal or vertical layouts, keyboard arrow-key navigation, ARIA roles, and nested content template support.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| tab_layout | select | 'horizontal' | No | Internal logic routing |
| tabs | REPEATER | 3 tabs | Yes | Contextual escaping (`esc_html`, `RenderHelper::esc_rich_text`) |
| - tab_title | text | 'Tab #1' | Yes | Contextual escaping (`esc_html`) |
| - tab_content | textarea | '...' | Yes | Strict XSS sanitization (`RenderHelper::esc_rich_text`) |
| active_tab | number | 1 | No | Absolute integer cast (`absint`) |
| design_variant | select | 'core' | No | `sanitize_key()` validation |

### HTML Structure
```html
<div class="astrax-widget astrax-tabs astrax-tabs-horizontal astrax-variant-core" role="tablist">
  <div class="astrax-tabs-nav">
    <button class="astrax-tab-nav-item is-active" role="tab" aria-selected="true" aria-controls="tab-1" id="tab-btn-1" tabindex="0">Tab 1</button>
  </div>
  <div class="astrax-tabs-content">
    <div class="astrax-tab-pane is-active" role="tabpanel" id="tab-1" aria-labelledby="tab-btn-1" tabindex="0">
      Content...
    </div>
  </div>
</div>
```

### Accessibility
- [x] Full `tablist`, `tab`, and `tabpanel` WAI-ARIA pattern implementation.
- [x] Keyboard navigation via Arrow Left/Right (Horizontal) or Arrow Up/Down (Vertical).
- [x] Home/End keyboard shortcuts to jump to first/last tab.
- [x] Visible focus rings on tab buttons.
