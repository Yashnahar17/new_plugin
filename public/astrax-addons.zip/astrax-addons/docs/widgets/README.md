# Widget Documentation

This folder contains the documentation structure for Astrax widgets. Every widget must define its expected controls, dynamic-tags compatibility, and UX behavior in a markdown file here.

## Template: Widget Name

### Description
Brief description of the widget.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| example_text | text | 'Default' | Yes | Contextual escaping (`esc_html`) |

### HTML Structure
Describe the semantic markup. E.g., `<div><h2>...</h2></div>`

### Accessibility
- [ ] Keyboard navigation.
- [ ] ARIA attributes/states.
- [ ] Reduced motion support (if applicable).
