# Advanced Button

### Description
A flexible button widget with accessibility states, robust link handling, and standard Elementor button semantics.

### Controls
| Control Name | Type | Default | Dynamic Supported | Security Handling |
| --- | --- | --- | --- | --- |
| button_text | text | 'Click Me' | Yes | Contextual escaping (`esc_html`) |
| button_link | URL | '#' | Yes | URL protocols sanitized natively by Elementor |

### HTML Structure
```html
<a href="#" class="astrax-button elementor-button elementor-size-md" role="button">
  <span class="elementor-button-content-wrapper">
    <span class="elementor-button-text">Click Me</span>
  </span>
</a>
```

### Accessibility
- [x] Standard `role="button"` for screen readers.
- [x] Keyboard focusable natively via `<a>` tag.
- [ ] Reduced motion support (pending styling layer in Phase 5).
