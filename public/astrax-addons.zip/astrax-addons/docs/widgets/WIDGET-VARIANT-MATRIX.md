# Astrax Addons — Widget Variant & Quality Matrix

This document provides the authoritative coverage matrix across design variants (Core, Editorial, Cyber), responsive scaling, accessibility compliance (WCAG 2.2 AA), and automated quality testing.

## Flagship & Reference Widgets

| Widget | Variant 1 (Core) | Variant 2 (Editorial) | Variant 3 (Cyber) | Responsive | Accessibility | Tested |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Advanced Heading** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Advanced Button** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Image Accordion** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Icon Box** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Info Box** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Post Grid** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Woo Product Grid** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Woo Product Carousel** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Woo Category Grid** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Interactive Tabs** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Filterable Gallery** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Bento Grid** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |

---

## Category Variant Inheritance

All 409 widgets in the Astrax platform inherit from `BaseWidget` and utilize the unified variant token engine (`core.css`, `editorial.css`, `cyber.css`). Setting the `design_variant` control to `core`, `editorial`, or `cyber` dynamically updates CSS custom properties (`--variant-surface`, `--variant-text`, `--variant-border`, `--variant-accent`) without rewriting structural markup.

| Category | Total Widgets | Variant Engine Attached | Mobile Viewport Tested (375px) | WCAG AA Focus Verified |
| :--- | :---: | :---: | :---: | :---: |
| **Content** | 22 | ✓ | ✓ | ✓ |
| **Images** | 17 | ✓ | ✓ | ✓ |
| **Typography** | 14 | ✓ | ✓ | ✓ |
| **Navigation** | 14 | ✓ | ✓ | ✓ |
| **Blog / Posts** | 26 | ✓ | ✓ | ✓ |
| **WooCommerce** | 34 | ✓ | ✓ | ✓ |
| **Forms** | 17 | ✓ | ✓ | ✓ |
| **Business** | 21 | ✓ | ✓ | ✓ |
| **Marketing** | 19 | ✓ | ✓ | ✓ |
| **Animation** | 18 | ✓ | ✓ | ✓ |
| **Interactive** | 20 | ✓ | ✓ | ✓ |
| **Data Visualization** | 15 | ✓ | ✓ | ✓ |
| **Maps** | 11 | ✓ | ✓ | ✓ |
| **Video / Audio** | 14 | ✓ | ✓ | ✓ |
| **FAQ / Docs** | 10 | ✓ | ✓ | ✓ |
| **User / Login** | 11 | ✓ | ✓ | ✓ |
| **Dynamic WP** | 20 | ✓ | ✓ | ✓ |
| **ACF / CPT** | 9 | ✓ | ✓ | ✓ |
| **Developer** | 11 | ✓ | ✓ | ✓ |
| **AI Widgets** | 13 | ✓ | ✓ | ✓ |
| **Creative UI** | 33 | ✓ | ✓ | ✓ |
| **Total** | **409** | **✓** | **✓** | **✓** |

---

## Visual & Interaction Signatures

### 1. Core Variant
- **Aesthetic**: Clean, modern, balanced corporate and SaaS styling.
- **Design Tokens**: Standard radius (8px), neutral borders (`#e2e8f0`), balanced sans-serif typography (`Inter`, `system-ui`).
- **Interactive State**: Subtle elevation lift with smooth cubic-bezier transitions (`cubic-bezier(0.16, 1, 0.3, 1)`).

### 2. Editorial Variant
- **Aesthetic**: High-fashion, luxury, magazine, and longform publishing.
- **Design Tokens**: Serif typography (`Playfair Display`, `Georgia`), warm cream surfaces (`#fdfbf7`), rich ink text (`#1a1a1a`), architectural borders.
- **Interactive State**: Elegant underline growth and sepia-to-full-color image transitions.

### 3. Cyber Variant
- **Aesthetic**: Futuristic, high-tech, Web3, and gaming.
- **Design Tokens**: Dark glassmorphic surfaces (`rgba(10, 15, 30, 0.85)`), electric neon accents (`#00f0ff`, `#7000ff`), monospace metadata tags, glowing outer borders.
- **Interactive State**: Neon glow amplification and subtle futuristic scale transforms.
