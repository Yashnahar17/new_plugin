# CI & Release Gate Specification

## Pre-commit & Build Checks
- **Syntax**: `php -l` checks on all files.
- **Linting**: PHPCS (WordPress Coding Standards).
- **Static Analysis**: PHPStan configured for maximum safe level.
- **Frontend**: ESLint, Stylelint, Prettier for assets.

## Testing Gates
- **Unit & Integration**: PHPUnit must pass at 100% execution for all tests.
- **E2E**: Playwright tests for frontend and editor functionalities must pass.
- **Accessibility**: Pa11y/axe-core checks integrated into the CI pipeline.

## Security & Supply Chain Gates
- **Dependency Scan**: Check for vulnerabilities in npm and composer lock files.
- **Secret Scan**: Repository scanning to prevent API keys or secrets in commits.
- **Release Package**: Final zip must NOT contain development files (`tests/`, `node_modules/`, `composer.json` overhead, secret configurations).

## Release Criteria (Security Matrix)
- 0 Critical/High exploitable vulnerabilities.
- 0 Authorization bypasses.
- 0 XSS / SQLi / CSRF paths.
- Compatibility Matrix fully verified.
