# Astrax Addons V3.0 Architecture Audit and Coverage Matrix

**Phase:** 0 — baseline audit  
**Audit basis:** source files in this repository as inspected on 2026-09-30. “Implemented” means a corresponding implementation file exists and the widget is explicitly registered. It is not a claim that every widget behavior has passed acceptance testing, accessibility review, or a security review.

## 1. Verified Architecture

| Area | Verified implementation | Audit notes |
| --- | --- | --- |
| Bootstrap | `AstraxAddons\\Core\\Plugin` | Private constructor and `get_instance()` singleton. Initializes compatibility, settings, REST, templates, then Elementor-bound assets, widgets, and extensions. See `includes/Core/Plugin.php`. |
| Composer loading | `AstraxAddons\\` maps to `includes/` | Declared in `composer.json`. |
| Widget registry | `AstraxAddons\\Widgets\\WidgetRegistry`, `WidgetManager` | A canonical registry defines 55 widgets for both Elementor registration and the REST/admin UI. Disabled widgets are omitted before their file is loaded or registered. |
| Shared widget base | `AstraxAddons\\Widgets\\BaseWidget` | Extends Elementor `Widget_Base`, uses `SharedControlsTrait`, and supplies category/help/tag helpers. See `includes/Widgets/BaseWidget.php`. |
| Shared controls | `AstraxAddons\\Utilities\\SharedControlsTrait` | Includes HTML tag, link, typography, and icon controls. See `includes/Utilities/SharedControlsTrait.php`. |
| Rendering and HTTP utilities | `RenderHelper`, `HttpHelper`, `QueryController` | Present under `includes/Utilities/`; individual usage and security properties remain subject to behavior-level review. |
| Extensions | `ExtensionManager` | Registers Wrapper Link, Visibility, Sticky, and Motion extensions. Its source comment says settings-based conditional loading is still to be wired. See `includes/Extensions/ExtensionManager.php`. |
| Assets | `AssetManager` | Centrally registers a subset of widget and extension assets; it does not itself implement per-widget conditional enqueue logic. See `includes/Assets/AssetManager.php`. |
| Templates | `TemplateManager`, `TemplateLibrary` | Registers the template CPT and contains JSON import/sanitization code. Import behavior needs dedicated security tests before being treated as a hardened import contract. |
| REST | `RestManager` and four controllers | Routes cover settings, widgets, extensions, and system status. The widget controller now reads the same 55-entry registry used by Elementor. Permission and validation still require controller-level behavior tests. |
| Admin assets | `assets/js/admin/dashboard.js`, `assets/css/admin/dashboard.css` | Files are present. This existence check does not establish dashboard completeness or runtime behavior. |
| CI and tests | `.github/workflows/ci.yml`; PHPUnit suite | CI has PHPUnit, PHPStan, and a PHPCS command with `|| true`, so PHPCS findings do not currently fail CI. The suite now includes focused identity/dependency coverage for the 25 planned widgets. |

## 2. Existing Widget Inventory

All 55 entries below have a corresponding implementation file and explicit registration in `WidgetManager`. Inventory is grouped by source namespace; this is not yet the final target-category taxonomy.

| Source group | Existing widgets |
| --- | --- |
| Core | Advanced Heading, Advanced Button, Icon Box, Info Box, Image Accordion, Post Grid, Woo Product Grid, Woo Product Carousel, Woo Category Grid |
| Content | Text Editor, Image Box, Dual Button, Call to Action, Badge, Notice, Blockquote, Content Toggle, Heading, Rich Text, Icon, Image, Image + Text, Button, Label, Divider, Spacer, Drop Cap, Highlight Text, Read More / Read Less |
| Images | Gallery, Before/After, Hotspots, Masonry Gallery, Justified Gallery, Image Carousel, Image Slider, Image Stack, Image Reveal, Image Mask, Image Hover Effects, Interactive Image, Floating Image, Scrolling Image, Image Magnifier, Lightbox Gallery |
| Typography | Animated Heading, Counter |
| Navigation | Breadcrumbs |
| Team | Team Card |
| Business | Pricing Table |
| Interactive | Tabs |
| Data | Google Map |
| Dynamic | Dynamic Field |
| Developer | Code Block |
| Creative | Bento Grid |

## 3. Target Coverage Matrix

Status is a Phase 0 inventory status, not a behavioral QA result. “Planned” means no corresponding target widget implementation was identified by this audit. Reuse entries are proposed implementation direction and should be checked against each target widget’s actual API and behavior before coding.

### Category 01 — Content

All Category 01 entries are present and registered. The twelve entries that were added after the original inventory use the shared `PlannedContentWidget` implementation; they need behavior-level acceptance, accessibility, and security coverage before being promoted beyond the baseline inventory status.

| Widget | Existing | Proposed reuse | New work | Status |
| --- | --- | --- | --- | --- |
| Heading | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Advanced Heading | Yes | `BaseWidget` | None | Implemented; registered |
| Text Editor | Yes | `BaseWidget` | None | Implemented; registered |
| Rich Text | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Icon | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Icon Box | Yes | `BaseWidget` | None | Implemented; registered |
| Image | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Image Box | Yes | `BaseWidget` | None | Implemented; registered |
| Image + Text | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Button | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Dual Button | Yes | Advanced Button patterns | None | Implemented; registered |
| Call to Action | Yes | `BaseWidget` | None | Implemented; registered |
| Badge | Yes | `BaseWidget` | None | Implemented; registered |
| Label | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Divider | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Spacer | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Notice | Yes | `BaseWidget` | None | Implemented; registered |
| Quote | Yes (Blockquote) | `BaseWidget` | None | Implemented; registered |
| Drop Cap | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Highlight Text | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |
| Content Toggle | Yes | `BaseWidget` | None | Implemented; registered |
| Read More / Read Less | Yes | `PlannedContentWidget` / `BaseWidget` | Behavior-level QA | Implemented; registered |

### Category 02 — Image

All Category 02 entries are present and registered. The thirteen entries added after the original inventory use the shared `PlannedGalleryWidget` or `PlannedImageEffectWidget` implementation. Their registration and declared dependencies are covered; layout, interaction, and responsive behavior still require acceptance testing.

| Widget | Existing | Proposed reuse | New work | Status |
| --- | --- | --- | --- | --- |
| Image Gallery | Yes | `BaseWidget` | None | Implemented (Gallery); registered |
| Masonry Gallery | Yes | `PlannedGalleryWidget` / Gallery patterns | Layout acceptance tests | Implemented; registered |
| Justified Gallery | Yes | `PlannedGalleryWidget` / Gallery patterns | Layout acceptance tests | Implemented; registered |
| Image Carousel | Yes | `PlannedGalleryWidget` / `BaseWidget` | Interaction acceptance tests | Implemented; registered |
| Image Slider | Yes | `PlannedGalleryWidget` / Carousel patterns | Interaction acceptance tests | Implemented; registered |
| Before/After Image | Yes | `BaseWidget` | None | Implemented; registered |
| Image Hotspots | Yes | `BaseWidget` | None | Implemented; registered |
| Image Accordion | Yes | `BaseWidget` | None | Implemented; registered |
| Image Stack | Yes | `PlannedImageEffectWidget` / `BaseWidget` | Layout acceptance tests | Implemented; registered |
| Image Reveal | Yes | `PlannedImageEffectWidget` / `BaseWidget` | Interaction acceptance tests | Implemented; registered |
| Image Mask | Yes | `PlannedImageEffectWidget` / `BaseWidget` | Visual acceptance tests | Implemented; registered |
| Image Hover Effects | Yes | `PlannedImageEffectWidget` / `BaseWidget` | Interaction acceptance tests | Implemented; registered |
| Interactive Image | Yes | `PlannedImageEffectWidget` / Hotspots patterns | Interaction acceptance tests | Implemented; registered |
| Floating Image | Yes | `PlannedImageEffectWidget` / `BaseWidget` | Motion acceptance tests | Implemented; registered |
| Scrolling Image | Yes | `PlannedImageEffectWidget` / `BaseWidget` | Scroll acceptance tests | Implemented; registered |
| Image Magnifier | Yes | `PlannedImageEffectWidget` / `BaseWidget` | Interaction acceptance tests | Implemented; registered |
| Lightbox Gallery | Yes | `PlannedGalleryWidget` / Gallery patterns | Lightbox acceptance tests | Implemented; registered |

### Categories 03–26

Not enumerated in this Phase 0 artifact. Their target widget names, existing coverage, reuse candidates, dependencies, and acceptance criteria must be added in category-sized planning updates before claiming a complete 200+ widget matrix. The roadmap phases are sequencing, not evidence that every category has been audited.

## 4. Shared Infrastructure Gaps

| Infrastructure | Phase 0 status | Next design/implementation gate |
| --- | --- | --- |
| Map provider interface | No provider abstraction found; Google Map widget exists | Define provider contract, key ownership, geocoding limits, privacy defaults, and fallback behavior before adding providers. |
| Social provider client | No provider client found | Specify supported APIs, credential storage, cache/expiry, rate limits, error states, and platform policy constraints. |
| Forms engine | No centralized forms module found | Define nonce and capability rules, field schema, sanitization/validation, spam controls, persistence, and response contract. |
| AI provider abstraction | No AI provider namespace/interface found | Define server-only secrets, provider request/response contract, permissions, quotas, timeout, and data handling. |
| Animation controls trait | No shared animation configuration trait found | Specify reduced-motion behavior and a stable control schema before adoption across widgets. |
| Widget enable/disable integration | Canonical registry now lists 55 widgets and is enforced before Elementor registration | Add integration coverage that persisted disabled widgets are not registered or loaded. |
| Enqueue strategy | Asset manager centrally registers only a subset of assets | Audit every widget dependency and ensure front-end assets load only when needed without missing editor assets. |
| Quality gates | PHPCS is non-blocking in CI | Decide whether to make PHPCS a required gate after establishing a baseline; retain PHPUnit and PHPStan as required checks. |

## 5. Phase 1 Exit Criteria

1. Each provider/engine has a documented interface, configuration boundary, failure contract, and focused tests before consumers depend on it.
2. Widget metadata has one source of truth shared by Elementor registration and REST/admin controls.
3. Enable/disable state is enforced at registration and covered by tests, not merely persisted by the REST controller.
4. Asset dependencies are declared by widgets and verified for frontend/editor contexts.
5. CI gates have explicit required/failure behavior; no lint job silently passes findings without a documented baseline exception.
6. Categories 03–26 receive a bounded inventory and acceptance criteria before their implementation phases begin.
