# Baseline Audit — 2026-09-30

## Scope and Evidence

This audit covers the source tree present on 2026-09-30. It verifies file presence, explicit Elementor registration, Composer quality commands, and the existing PHPUnit suite. It does not certify runtime WordPress, Elementor, WooCommerce, browser, accessibility, or security behavior.

## Verified Inventory

- The PSR-4 `AstraxAddons\\` namespace maps to `includes/` in `composer.json`.
- `Core\\Plugin` is the singleton bootstrapper and initializes compatibility, admin settings, REST, templates, assets, widgets, extensions, and i18n.
- `WidgetRegistry` is the canonical source for 55 widget definitions. `WidgetManager` registers only enabled definitions, and the REST widget controller reads the same registry.
- The original core/reference widgets, REST controllers, extensions, template classes, query helper, and WooCommerce widgets named in the implementation summary exist in the repository.
- The Content and Image matrices now contain 25 additional registered widgets. These use two shared classes, `PlannedContentWidget` and `PlannedGalleryWidget` / `PlannedImageEffectWidget`; their existence must not be read as full feature or acceptance completion.

## Quality Gate Results

| Command | Result | Evidence |
| --- | --- | --- |
| `composer test` | Pass | PHPUnit 9.6.37: 16 tests, 65 assertions. |
| `composer lint` | Blocked | `phpcs.xml.dist` references WordPress sniffs that are not installed in `vendor/`; PHPCS exits with code 3. |
| `composer analyze` | Fail | PHPStan reports 618 errors. Most originate from absent WordPress/Elementor type definitions and incomplete PHPStan configuration; the current config also has unmatched ignored-error patterns. |

## Release-Blocking Findings

1. PHPCS is configured but cannot run because the WordPress Coding Standards dependency is absent. CI masks this failure with `|| true`, so lint findings cannot fail a build.
2. PHPStan is not a usable release gate. The current configuration reports 618 errors and runs against no WordPress or Elementor stubs.
3. The test suite mainly proves identity, registration-related declarations, and utility behavior. It does not prove widget rendering, REST authorization, template import safety, asset loading, accessibility, or browser interactions.
4. The documented coverage matrix previously showed 25 registered widgets as planned. It has been corrected to separate registration evidence from behavior-level QA.

## Required Next Steps

1. Add compatible WordPress Coding Standards dependencies, remove the CI bypass, and establish a documented lint baseline.
2. Add maintained WordPress and Elementor PHPStan stubs or a narrowly scoped baseline, then resolve real application findings before claiming static-analysis coverage.
3. Add integration tests for disabled widget registration, REST permissions and nonces, template import validation, and the query/HTTP security boundaries.
4. Add browser and keyboard/accessibility acceptance tests for interactive widgets before their individual completion status is upgraded.
