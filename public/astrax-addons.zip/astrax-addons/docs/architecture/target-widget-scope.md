# Target Widget Scope

**Source:** canonical inventory supplied on 2026-09-30.  
**Counting rule:** individual list entries are authoritative when a category heading conflicts with its entries.

## Inventory

| Category | Entries |
| --- | ---: |
| Content | 22 |
| Images | 17 |
| Typography | 14 |
| Navigation | 14 |
| Blog / Posts | 26 |
| Team | 11 |
| Testimonials | 12 |
| Social Media | 13 |
| WooCommerce | 34 |
| Forms | 17 |
| Business | 21 |
| Marketing | 19 |
| Animation | 18 |
| Interactive | 20 |
| Data Visualization | 15 |
| Maps | 11 |
| Video / Audio | 14 |
| FAQ / Documentation | 10 |
| User / Login | 11 |
| Dynamic WordPress | 20 |
| ACF / CPT | 9 |
| Developer | 11 |
| AI | 13 |
| Premium Creative UI | 32 |
| **Total** | **414** |

## Normalization Rules

This inventory is a product catalog, not a requirement for 414 duplicated PHP classes. One canonical widget may satisfy repeated entries where behavior is the same, including Counter, Pricing Table, Image Accordion, Before/After, FAQ, Progress Bar, Google Maps, OpenStreetMap, and comparison tables. Distinct interaction models, data sources, or accessibility contracts require distinct implementations.

## Delivery Gates

Each implementation cycle must update the coverage matrix with class, controls, dependencies, security boundary, keyboard behavior, reduced-motion behavior, tests, and documentation. A registered class alone does not mark a widget complete.

## Delivery Order

1. Canonical widget metadata and enable/disable enforcement.
2. Shared forms, maps, social, AI, and animation interfaces.
3. Typography and Navigation.
4. Posts, Team, Testimonials, Social, and WooCommerce.
5. Forms, Business, Marketing, Animation, Interactive, Data, Maps, and Media.
6. Documentation, User, Dynamic WordPress, ACF/CPT, Developer, AI, and Creative UI.
