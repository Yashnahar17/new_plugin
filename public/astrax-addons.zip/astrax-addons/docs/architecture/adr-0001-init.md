# Architecture Decision Record (ADR) 0001: Initial Architecture

## Status
Accepted

## Context
We need a scalable, secure, and maintainable foundation for Astrax Addons for Elementor, designed to grow from 5 reference widgets to a large ecosystem.

## Decision
We will adopt a modular, PSR-4 compliant namespace architecture (`AstraxAddons\`).
The plugin will be divided into the following namespaces:
- `Core`: Bootstrap, plugin lifecycle, and dependency injection.
- `Compatibility`: System checks (PHP, WP, Elementor versions).
- `Assets`: Centralized registration for scripts and styles.
- `Widgets`: Elementor widget classes.
- `Extensions`: Elementor extensions (e.g., wrappers, sticky effects).
- `Admin`: WordPress dashboard interfaces.
- `REST`: API endpoints.
- `Security`: Nonce, sanitization, and capability helpers.
- `Utilities`: General helpers (rendering, templates).

## Consequences
- **Positive**: High maintainability, easy testing through PHPUnit, separation of concerns.
- **Negative**: Slight initial overhead for setting up autoloader (Composer) and structure.

## Next Steps
Initialize Composer, setup PSR-4 autoloader, and scaffold Phase 1 structure.
