# ADR 0002: Shared Controls and Systems Architecture

## Status
Accepted

## Context
Across our 5 reference widgets (Advanced Heading, Advanced Button, Icon Box, Info Box, and Image Accordion), several control definitions were identical or duplicated:
1. Allowlisted HTML Tag selection (`h1`-`h6`, `div`, `span`, `p`) with semantic defaults.
2. Link control configurations (dynamic capability, placeholder standards, URL structure).
3. Typography Group Controls with scoped selectors.
4. Icon controls using Elementor's `Icons_Manager`.

In accordance with Phase 5 of the Master Plan ("Build shared typography, responsive, media, link, icon, animation and accessibility systems *only where they reduce proven duplication*"), we needed a clean, native mechanism to eliminate boilerplate without inventing proprietary layers or breaking Elementor standards.

## Decision
We implemented `SharedControlsTrait` in `includes/Utilities/SharedControlsTrait.php` and consumed it via `BaseWidget`:
1. `add_html_tag_control()`: Standardizes safe HTML element choice across headings and text wrappers.
2. `add_link_control()`: Standardizes URL controls with dynamic tag support.
3. `add_typography_control()`: Binds Elementor's `Group_Control_Typography` with consistent CSS scoping.
4. `add_icon_control()`: Standardizes SVG/FontAwesome icon picker integration.

## Consequences
- **Positive**: 
  - Significant reduction of duplicated array declarations across widgets.
  - Consistent default tags and labels across all widgets.
  - Native Elementor control schemas are preserved without abstraction bloat.
  - Full backward compatibility and high test coverage.
- **Negative**:
  - Trait methods must be maintained to match future Elementor Group Control API signatures.
