# Widget Delivery Phases

## Counting Rule

The supplied category counts total **404** individual entries, despite the source stating 414. This plan uses the individual entries as authoritative: nine phases of 41 widgets and a final phase of 35 widgets.

Each phase is a delivery batch, not a claim that all its widgets are complete on registration. A widget completes only after controls, rendering, scoped assets, responsive behavior, keyboard support, reduced-motion behavior, security review, tests, and documentation are present.

| Phase | Scope | Entry count |
| --- | --- | ---: |
| 1 | Content (22), Images (17), Typography: Animated Heading and Text Marquee (2) | 41 |
| 2 | Remaining Typography (12), Navigation (14), Blog / Posts: Post Grid through Post Content (15) | 41 |
| 3 | Remaining Blog / Posts (11), Team (11), Testimonials (12), Social Media: Facebook through LinkedIn (7) | 41 |
| 4 | Remaining Social Media (6), WooCommerce (34), Forms: Contact Form (1) | 41 |
| 5 | Remaining Forms (16), Business (21), Marketing: CTA through Promo Banner (4) | 41 |
| 6 | Remaining Marketing (15), Animation (18), Interactive: Accordion through Off-Canvas (8) | 41 |
| 7 | Remaining Interactive (12), Data Visualization (15), Maps (11), Video / Audio: Video through Video Carousel (3) | 41 |
| 8 | Remaining Video / Audio (11), FAQ / Documentation (10), User / Login (11), Dynamic WordPress: Dynamic Posts through Dynamic URLs (9) | 41 |
| 9 | Remaining Dynamic WordPress (11), ACF / CPT (9), Developer (11), AI: AI Text Generator through AI Form Assistant (10) | 41 |
| 10 | Remaining AI (3), Premium Creative UI (32) | 35 |

## Phase Gate

1. Canonical registry metadata is added for the batch.
2. Shared provider or form dependencies are implemented before consumers.
3. Widgets use plugin-owned semantic markup and conditional local assets.
4. Interactive widgets support keyboard operation, focus visibility, and reduced motion.
5. Forms, AI, social, and map widgets preserve server-side authorization and secret boundaries.
6. Unit/integration coverage and widget documentation are added before the batch is marked complete.
7. Regression checks must pass; PHPCS and PHPStan remain release blockers until their existing configuration gaps are resolved.
