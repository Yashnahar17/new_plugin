# Standards Specification

## WordPress.org Compliance
- All code is licensed under GPLv2 or later.
- Source code remains human-readable; no obfuscation is allowed.
- Telemetry or tracking is strictly prohibited without explicit user opt-in.
- No execution of remote code.
- Admin dashboard must not hijack the UI or place unauthorized public-site links.

## Coding Standards
- **PHP**: WordPress Coding Standards via PHPCS. Use namespaces (`AstraxAddons\`).
- **JavaScript**: ESLint with WordPress/Elementor guidelines.
- **CSS**: Stylelint.
- **Strict Typing**: Use PHPStan for static analysis.

## Security Standards
- Absolute path protection (`ABSPATH`) in all files.
- Input validation and sanitization (`sanitize_text_field`, etc.).
- Output escaping (`esc_html`, `esc_attr`, `wp_kses`).
- Server-side capability checks (`current_user_can`).
- CSRF protection using Nonces.
- Safe SQL with `$wpdb->prepare()`.

## Elementor Integration
- Use documented official Elementor APIs (Widget_Base, Controls).
- Register assets conditionally (only load CSS/JS when a widget is present).
- Safe dynamic content implementation.

## Accessibility
- WCAG 2.2 AA target.
- Keyboard navigation, visible focus, aria-labels.
- Reduced motion support.
- Semantic HTML tags.
