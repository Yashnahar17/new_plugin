# Compatibility Matrix

| Dependency | Minimum Version | Tested Up To | Notes |
|------------|-----------------|--------------|-------|
| PHP        | 7.4             | 8.3          | Follow modern PHP practices, downgrade syntax in build if needed, or enforce 7.4. |
| WordPress  | 6.0             | 6.6          | Core CMS functions. |
| Elementor  | 3.16            | 3.24         | Core addon target. |
| Elementor Pro | (Optional)    | Latest       | Test for conflicts; no hard dependency. |
| WooCommerce| (Optional)      | 9.x          | Required only for WooCommerce specific extensions. |

## Strategy
- Implement a Compatibility Manager class during bootstrap.
- If dependencies fail (e.g., Elementor not active or WP version too old), display an admin notice and halt initialization gracefully without fatal errors.
