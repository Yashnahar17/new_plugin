# License & Data-Flow Inventory

## License Inventory
- **Plugin Code**: GNU General Public License v2 or later (GPL-2.0+).
- **Dependencies (PHP)**: All Composer dependencies must be GPL compatible. To be generated and locked via `composer.json`.
- **Dependencies (JS/CSS)**: All NPM dependencies bundled in the final package must be GPL/MIT compatible.
- **Assets (Fonts, Icons, Images)**: Only use Open Source / SIL OFL licensed assets.

## Data-Flow Inventory
- **No Telemetry**: The plugin will not send any usage data, tracking, or telemetry back to any Astrax servers.
- **Third-Party Services**: Any API integration (e.g., Google Maps, Mailchimp) must have an explicit UI where the user inputs their own API key, along with clear privacy disclosures about what data is sent to the third party.
- **Local Storage**: Widget configurations are stored securely within standard Elementor/WordPress post meta databases.
