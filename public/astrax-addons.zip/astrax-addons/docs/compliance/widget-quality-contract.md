# Astrax Addons — Widget Quality Contract & Acceptance Specification

> **Document Type**: Normative Quality Standard  
> **Status**: Active (Phase 5)  
> **Applicability**: All 405 Elementor Widgets in Astrax Addons  

---

## 1. The Quality Contract Model

Every widget in Astrax Addons must fulfill a strict 100-point quality framework across 12 dimensions:

| Criterion | Max Points | Description |
|---|---|---|
| **1. PHP Correctness** | 10 | Strict PHP syntax, correct namespace, PSR-4 path, no deprecated functions. |
| **2. Elementor Registration** | 10 | Unique `get_name()`, valid title, icon, registration in `WidgetRegistry.php`. |
| **3. Meaningful Controls** | 10 | Tab Content, Tab Style, responsive controls where applicable, proper defaults. |
| **4. Semantic Rendering** | 10 | Clean semantic HTML, stable `.astrax-*` classes, empty/error state handling. |
| **5. Responsive Design** | 10 | Breakpoint handling (Desktop, Tablet, Mobile) with zero overflow. |
| **6. Accessibility (A11y)** | 10 | ARIA attributes on interactive items, screen-reader text, focus rings. |
| **7. Security & Sanitization** | 10 | `esc_html`, `esc_attr`, `wp_kses_post`, bounded queries, direct access guards. |
| **8. Performance** | 10 | Conditional asset declarations, bounded loops, transient caching if applicable. |
| **9. Editor Compatibility** | 5 | Live reload in Elementor preview, no JS console exceptions on element ready. |
| **10. Frontend Compatibility**| 5 | Clean DOM output without theme or third-party style pollution. |
| **11. Automated Testing** | 5 | Unit or integration test coverage for registration, controls, or rendering. |
| **12. Documentation** | 5 | Dedicated entry in `docs/widgets/{slug}.md` with controls and usage guide. |
| **TOTAL** | **100** | **Minimum Passing Score for Production Status: 85/100** |

---

## 2. Zero-Tolerance Critical Failures (Automatic Rejection)

Regardless of the calculated numerical score, a widget is classified as **FAILED / INCOMPLETE** if it triggers any of the following:

1. **Fatal Runtime Exception**: Uncaught PHP fatal error, undefined method, or missing class.
2. **Security Vulnerability**: Unescaped dynamic user input rendered directly in HTML/attributes (XSS risk).
3. **Ghost Controls**: Visual style controls that target CSS selectors that do not exist in the rendered DOM.
4. **Missing Production Asset**: Declaring a CSS/JS handle that does not exist in `assets/`.
5. **Theme Pollution**: Unscoped generic CSS class (e.g. `.title`, `.card`) injected into the global stylesheet.
6. **Keyboard Inaccessibility**: Interactive widget (modal, tab, accordion) that cannot be operated via keyboard.

---

## 3. Standard Verification Checklist

```text
[ ] PHP syntax valid
[ ] Class inherits from BaseWidget (or verified specialized parent)
[ ] get_name() returns unique astrax-* slug
[ ] get_title() wrapped in esc_html__() with 'astrax-addons' textdomain
[ ] register_controls() contains Content and Style sections
[ ] render() produces semantic markup with stable .astrax-* classes
[ ] Style controls match actual rendered classes
[ ] get_style_depends() and get_script_depends() declare only verified handles
[ ] Empty state rendered gracefully when data is absent
[ ] Dynamic attributes sanitized via esc_attr() and esc_html()
```
